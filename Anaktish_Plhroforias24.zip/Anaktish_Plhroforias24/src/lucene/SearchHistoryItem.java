package lucene;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchHistoryItem {
    
    private static Map<String, Integer> history = new HashMap<>();
    private static ArrayList<String> searchHistory = new ArrayList<String>();

    
    public static void addToHistory(String query) {
        try {
           
            File file = new File("C:/temp/indexluc/search_history.txt");
            FileWriter writer = new FileWriter(file, true);
            
            // Write the query to the file and add it to the search history list
            writer.write(query + "\n");
            searchHistory.add(query);
            
            // Close the file writer
            writer.close();
        } catch (IOException e) {
            System.err.println("Error writing to search history file: " + e.getMessage());
        }
    }

    
    public static List<String> getRecommendations() {
        List<String> recommendations = new ArrayList<>();
        for (String searchTerm : history.keySet()) {
            if (history.get(searchTerm) >= 3) {
            	
                recommendations.add("Have you tried searching for " + searchTerm + "?");
            }
        }
        return recommendations;
    }
}

