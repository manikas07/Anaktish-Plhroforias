package lucene;

import javax.swing.*;
import java.awt.*;


import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.apache.lucene.analysis.*;
import org.apache.lucene.analysis.standard.*;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.*;
import org.apache.lucene.search.*;
import org.apache.lucene.store.*;
import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.BadLocationException;
import javax.swing.text.Highlighter;
import javax.swing.text.JTextComponent;

public class LuceneGUI extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    private static final String INDEX_DIRECTORY = "C:\\temp\\indexluc";
    boolean flag = false;
    private JLabel queryLabel;
    private JTextField queryField;
    private JCheckBox titleCheckbox;
    private JCheckBox yearCheckbox;
    private JCheckBox abstractCheckbox;
    private JButton searchButton;
    private JButton moreButton;
    private JButton sortButton;
    private JTextArea resultArea;
    private JTextArea historyArea;

    private Analyzer analyzer;
    private Directory directory;
    private IndexSearcher searcher;
    
    private int cPage = 0;
    private int allPages = 0;
    private ArrayList<String> searchHistory;
    private String strQuery;
    private int firstsearch = 0;
    private int more_counter_display = 0; 
    private TopDocs cResults;

    public LuceneGUI() throws Exception {
        queryLabel = new JLabel("Query:");
        queryField = new JTextField(20);
        titleCheckbox = new JCheckBox("Title");
        yearCheckbox = new JCheckBox("Year");
        abstractCheckbox = new JCheckBox("Abstract");
        searchButton = new JButton("Search");
        moreButton = new JButton("More");
        sortButton = new JButton("Sort by Year");
        resultArea = new JTextArea(20, 50);
        historyArea = new JTextArea();
        historyArea.setEditable(false);
        searchHistory = new ArrayList<String>();
        JScrollPane scrollPane = new JScrollPane(resultArea);
        JScrollPane historyScrollPane = new JScrollPane(historyArea);

        historyScrollPane.setPreferredSize(new Dimension(200, 400));

        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        setLayout(new BorderLayout());
        JPanel topPanel = new JPanel(new FlowLayout());
        topPanel.add(queryLabel);
        topPanel.add(queryField);
        topPanel.add(titleCheckbox);
        topPanel.add(yearCheckbox);
        topPanel.add(abstractCheckbox);
        topPanel.add(searchButton);
        topPanel.add(sortButton);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, historyScrollPane, scrollPane);
        splitPane.setResizeWeight(0.3);  

        add(topPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);

        // fortwsh search history
        loadSearchHistory();

        // arxikopoihsh lucene
        analyzer = new StandardAnalyzer();
        directory = FSDirectory.open(Paths.get(INDEX_DIRECTORY));
        IndexReader reader = DirectoryReader.open(directory);
        searcher = new IndexSearcher(reader);

       
        searchButton.addActionListener(this);
        sortButton.addActionListener(this);
        resultArea.remove(moreButton);
       
        
    }

    private void loadSearchHistory() {
        try {
            File file = new File("C:\\temp\\indexluc\\search_history.txt");
            if (!file.exists()) {
                file.createNewFile();
            }
            BufferedReader reader = new BufferedReader(new FileReader(file));
            StringBuilder sb = new StringBuilder();
            String line;
            int count = 0;
            while ((line = reader.readLine()) != null && count < 10) {
                sb.append(line).append("\n");
                count++;
            }
            reader.close();
            historyArea.setText(sb.toString());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == searchButton) {
            loadSearchHistory();  // ananewsh tou search history gia na emfanistei xwris na trexoume tin efarmagh xana
            performSearch();
        } else if (e.getSource() == sortButton) {
            try {
                if (cResults != null) {
                    sortResultsByYear(cResults);
                    displayResults(cResults, 0, 10);
                    cPage = 1;
                }
            } catch (Exception ex) {
                resultArea.setText("Error: " + ex.getMessage());
            }
        }
    }

    private void performSearch() {
        try {
            String searchText = queryField.getText().trim();
            
            Query query;
            if (titleCheckbox.isSelected()) {
                QueryParser parser = new QueryParser("title", analyzer);
                flag = true;
                query = parser.parse(searchText);
            } else if (yearCheckbox.isSelected()) {
                QueryParser parser = new QueryParser("year", analyzer);
                query = parser.parse(searchText);
            } else if (abstractCheckbox.isSelected()) {
                QueryParser parser = new QueryParser("abstract", analyzer);
                query = parser.parse(searchText);
            } else {
                QueryParser parser = new QueryParser("full_text", analyzer);
                query = parser.parse(searchText);
            }
            
            TopDocs results ;
            int totalResults;
            if (flag == true){
            	 results = searcher.search(query, 1000);
            	 totalResults = 1;
            	 flag = false;
            }else {
            	 results = searcher.search(query, 1000);
            	 totalResults = (int) results.totalHits.value;
            }

            strQuery = query.toString();
            searchHistory.add(strQuery);

            allPages = (totalResults / 10) + 1;
            this.cResults = results;
            
            displayResults(cResults, 0, 10);
            cPage = 1;

            JPanel topPanel = (JPanel) getContentPane().getComponent(0);
            JPanel buttonPanel = new JPanel();
            searchButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    ActionListener[] listeners = moreButton.getActionListeners();
                    if (listeners.length > 0) {
                        moreButton.removeActionListener(listeners[0]);
                    }
                }
            });

            moreButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        if (cPage != allPages) {
                            displayResults(cResults, (cPage * 10), 10);
                            cPage++;
                        } else {
                            displayResults(cResults, (cPage * 10), 10);
                            cPage = 1;
                        }
                    } catch (Exception ex) {
                        resultArea.setText("Error: " + ex.getMessage());
                    }
                }
            });
            buttonPanel.add(moreButton);
            if (!topPanel.isAncestorOf(moreButton)) {
                topPanel.add(Box.createHorizontalStrut(10));
                topPanel.add(moreButton);
            }
            moreButton.setVisible(true);
            topPanel.add(buttonPanel);
            if (firstsearch == 0) {
                pack();
                firstsearch++;
            }
            topPanel.add(moreButton, BorderLayout.LINE_END);
            searchHistory.add(strQuery);
            SearchHistoryItem.addToHistory(strQuery);
        } catch (Exception ex) {
            resultArea.setText("Error: " + ex.getMessage());
        }
    }

    private void sortResultsByYear(TopDocs results) throws IOException {
        ScoreDoc[] scoreDocs = results.scoreDocs;
        Arrays.sort(scoreDocs, new Comparator<ScoreDoc>() {
            public int compare(ScoreDoc d1, ScoreDoc d2) {
                try {
                    Document doc1 = searcher.doc(d1.doc);
                    Document doc2 = searcher.doc(d2.doc);
                    String year1 = doc1.get("year");
                    String year2 = doc2.get("year");
                    if (year1 != null && year2 != null) {
                        return year2.compareTo(year1);  //apo to pio konta se emas sto palaiotero
                    }
                    return 0;
                } catch (IOException e) {
                    e.printStackTrace();
                    return 0;
                }
            }
        });
        results.scoreDocs = scoreDocs;
    }

    private void displayResults(TopDocs results, int start, int count) throws Exception {
        resultArea.setText("");
        resultArea.removeAll();

        if (start == 0) {
            more_counter_display = 0;
        }
        int totalResults = (int) results.totalHits.value;
        int totalPages = (totalResults / count) + 1;
        if (start >= totalPages * count) {
            start = 0;
            more_counter_display = 0;
        }

        int end = Math.min(start + count, totalResults);

        for (int i = start; i < end && i < results.scoreDocs.length; i++) {
            ScoreDoc scoreDoc = results.scoreDocs[i];
            Document doc = searcher.doc(scoreDoc.doc);
            String title = doc.get("title");
            String year = doc.get("year");
            String full_text = doc.get("full_text");

            resultArea.append("Title: " + title + "\n" + "Year: " + year + "\nFullText: " + full_text + "\n\n");
        }

        int currentPage = start / count + 1;
        resultArea.append("Page " + currentPage + " of " + totalPages + "\n");

        if (end < totalResults) {
            final int finalStart = start;
            JButton moreButton = new JButton("More");
            moreButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        int currentStart = finalStart;
                        displayResults(results, currentStart, count);
                    } catch (Exception ex) {
                        resultArea.setText("Error: " + ex.getMessage());
                    }
                }
            });
            resultArea.add(moreButton);
        }

        highlightText(resultArea, queryField.getText().trim());
        if(more_counter_display==0) 
          {
              ArrayList<String> recommendations = new ArrayList<>(SearchHistoryItem.getRecommendations());
              File file = new File("C:\\temp\\indexluc\\search_history.txt");
              if (file.exists()) {
                    BufferedReader reader1 = new BufferedReader(new FileReader(file));
                    String line;
                    while ((line = reader1.readLine()) != null) {
                        if (!line.equals(strQuery)) { // oxi auto pou evale twra o xrhsths
                              recommendations.add(line);
                         }
                      }
                      reader1.close();
                  }
              more_counter_display++;
              if (!recommendations.isEmpty()) {
	              System.out.println("Based on your search history, we recommend the following searches: ");
	              for (String str : recommendations) {
	                  System.out.println(str);
	              }
              }
          }
    }
    
    // Method to highlight the search query in the JTextArea
    private void highlightText(JTextComponent textComp, String pattern) {
        try {
            Highlighter myHighlighter = textComp.getHighlighter();
            javax.swing.text.Document doc = textComp.getDocument();
            String text = doc.getText(0, doc.getLength());
            int pos = 0;


            myHighlighter.removeAllHighlights();

            // Search for pattern and highlight all occurrences
            while ((pos = text.toLowerCase().indexOf(pattern.toLowerCase(), pos)) >= 0) {
                myHighlighter.addHighlight(pos, pos + pattern.length(), new DefaultHighlighter.DefaultHighlightPainter(Color.GREEN));
                pos += pattern.length();
            }
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        try {
            LuceneGUI gui = new LuceneGUI();
            gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            gui.setTitle("Search Scientific Articles");
            gui.pack();
            gui.setVisible(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
