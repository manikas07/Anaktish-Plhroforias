package lucene;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.document.Field;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;

public class LuceneIndex {

    private static final String INDEX_DIRECTORY = "C:\\temp\\indexluc";
    private static final String CSV_FILE_PATH = "C:\\Users\\lefte\\Documents\\GitHub\\Anaktish-Plhroforias\\papers.csv";

    public static void main(String[] args) {
        LuceneIndex luceneIndexing = new LuceneIndex();
        luceneIndexing.indexDocuments();
        luceneIndexing.search("1987");
    }

    public void indexDocuments() {
        try {
            Directory indexDir = FSDirectory.open(Paths.get(INDEX_DIRECTORY));
            Analyzer analyzer = new StandardAnalyzer();
            IndexWriterConfig config = new IndexWriterConfig(analyzer);
            IndexWriter indexWriter = new IndexWriter(indexDir, config);

            BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE_PATH));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length == 4) {
                    Document doc = new Document();
                    //doc.add(new TextField("source_id", fields[0], Field.Store.YES));
                    doc.add(new TextField("year", fields[0], Field.Store.YES));
                    doc.add(new TextField("title", fields[1], Field.Store.YES));
                    doc.add(new TextField("abstract", fields[2], Field.Store.YES));
                    doc.add(new TextField("full_text", fields[3], Field.Store.YES));
                    indexWriter.addDocument(doc);
                }
            }
            indexWriter.close();
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void search(String queryString) {
        try {
            Directory indexDir = FSDirectory.open(Paths.get(INDEX_DIRECTORY));
            IndexReader reader = DirectoryReader.open(indexDir);
            IndexSearcher searcher = new IndexSearcher(reader);

            Analyzer analyzer = new StandardAnalyzer();
            QueryParser parser = new QueryParser("year", analyzer);
            Query query = parser.parse(queryString);

            TopDocs topDocs = searcher.search(query, 1000);
            System.out.println("Total hits: " + topDocs.totalHits);

            for (ScoreDoc scoreDoc : topDocs.scoreDocs) {
                Document doc = searcher.doc(scoreDoc.doc);
                System.out.println("Title: " + doc.get("title"));
                System.out.println("Year: " + doc.get("year"));
                System.out.println("Abstract: " + doc.get("abstract"));
                System.out.println("Full Text: " + doc.get("full_text"));
                System.out.println();
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}

